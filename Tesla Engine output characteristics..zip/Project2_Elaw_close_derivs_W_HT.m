function diffs = Project2_Elaw_close_derivs_W_HT(theta,y, k, Vd, R, r, m_mix, n, a,thetas,thetad, Qhv, AF, L, B, N, Rsp)
    P = y(1);
    W = y(2);
    %m = y(3);                                                             %opened system only
    [V, dV] = volume(theta, Vd, R, r);
    
        if (theta < thetas)
            Q_comb = 0; %no heat add if not in comb phase
        elseif (theta >= thetas+thetad)
            Q_comb = 0; %no heat add if not in comb phase
        else
            Q_comb = (m_mix*(Qhv/(AF+1))*((n*a)/thetad)*((theta-thetas)/thetad).^(n-1))*exp(-a*((theta-thetas)/thetad)^n);
        end
    
    %Q_HT = h*Area(theta)*(T(theta))-Twall
        
    Area = Project2_area_(theta,L,B,R);
    Rho = m_mix/V;
    Up = 2*L*N/60;
    T = P*V/(Rsp*m_mix);                                                   %temp related to theta
    mu = (3.3e-7)*T^0.7;                                                   %kg/(m*s)
    ac = 0.49;                                                             %Annand Cor
    Tw = 85+273;                                                           %wall/coolant temp (*C)
    Re = (Rho*Up*B)/mu;                                                    %mu is on kg/m^2
    Nu = ac*(Re^0.7);                                                      %Nusselt number
    k_ht = (1.52e-4) + (4.42e-5)*T + (8e-9)*T^2; 
    h = (Nu*k_ht)/B;
    Q_ht = (h*Area*(T-Tw))/(1000*2*pi*(N/60));
    %Q_ht = 0;
    
    dP = ((k-1)/V)*(Q_comb - (Q_ht)) - k*P*dV/V;                           %Heat loss - Q comb - Work done
    dW = P*dV;
    diffs = [dP; dW];
end