



%N = 2000;                                                                 %RPM
Vd = 2;                                                                    %displacement volume L (2L in final version)
r = 10;                                                                    %compression ratio
np = 6;                                                                    %number of cylinders
L = (4*(Vd*0.001)/(pi*np))^(1/3);                                          %Stroke (m)
a = L/2;                                                                   %Half stroke, (m)
lc = 0.16;                                                                 %connecting rod length (m)
R = lc/a;                                                                  %Geometric ratio
k = 1.35;                                                                  %adiabatic  constant
Rsp = 0.287;                                                               %R_Specific
Cv = Rsp/(k-1);
Cp = k*Rsp/(k-1);
T1 = 60+273.15;                                                            %initial temperature
Tmax = 600+273; 
Nmax = 8000;                                                               %RPM
Pam = 101.325;                                                             %Ambient pressure(kpa)
ex = 2;                                                                    %Num of exhaust valves
in = 2;                                                                    %Num of intake valves
Vin = 2*L*Nmax/60;                                                         %Intake valve Velocity
Vex = 2*L*Nmax/60;                                                         %Exhaust valve velocity
cf = 0.6;                                                                  %Valve coefficient

%%%% Task 6 %%%%
%Heat transfer
%cyclinder dimensions
%L = 0.162;                                                                %length
B = L;                                                                     %0.162; %
R = 4.5;                                                                   %Radius

%%%%Task 5%%%%
%Combustion
thetas = -20*pi/180;                                                       %spark angle
thetad = 40*pi/180;                                                        %comb end angle
n = 3;
a = 5;
Qhv = 43400;                                                               %Heating[kj/kg]
AF = 21;                                                                   %Air fuel ratio
eta_c = 1;                                                                 %Combustion efficiency
Qin = Qhv*eta_c/(AF+1);

Vbdc = 0.001*Vd*(r/(r-1))/np;                                              %BDC volume[m^3]
m_mix = Pam*(Vbdc) / (Rsp*T1);  

i = 1;
Power = zeros(1,20);
Torque = zeros(1,20);
RPM = zeros(1,20);
PBr = zeros(1,20);
TBr = zeros(1,20);
Work4 = zeros(1,20);
WorkPump = zeros(1,20);

for N = 1000:100:6000



%%%%Task 7%%%%
%Intake & Exhaust Valve dimensions
Vci = (k*Rsp*1000*T1)^0.5;                                                 %Speed of sound intake
Vce = (k*Rsp*1000*Tmax)^0.5;                                               %Speed of sound exhaust

Ain = (1.3*(B^2)*(Vin/(Vci*cf)));                                          %Intake area
Aex = (1.3*(B^2)*(Vex/(Vce*cf)));                                          %Exhaust area

Din = ((4*Ain)/(pi))^0.5;     %Ex Dia
Dex = ((4*Aex)/(pi))^0.5;     %Ex Dia

%Get pressure drop
T0 = 30+273; %guess of t0 inlet
muin = (3.3e-7)*T0;
Rhoin = 1.225;       %m_mix/((pi*(Din^2)/4))*D*1000;                       %Air density in intake valve (Ambient air density at intake kg/m^3)
Aintake = ((B^2)*pi)/4;

Vintake = (((np*m_mix/(1+(1/AF)))*(N/(60*2)))/(Rhoin*Aintake));
Re_7 = Rhoin*Vintake*B/muin; 

f = 1/(-1.8*log(((0.01/3.7).^1.11)+(6.9/Re_7)))^2;                         %Friction factor

DelP = f*0.5*Rhoin*(Vintake^2)*1000;                                       %Pressure drop during intake manifold

%P drop inlet valve
Upbar = 2*L*N/60;
Pi = Pam*1000 - DelP;
cv = 4.12e-3;                                                              %const
DelPiv = cv*1000*((((Pi)*Upbar*(B^2))/((Pam*1000)*in*(Din^2))))^2;         %Pressure drop during intake valve
DelPev = cv*1000*((((Pi)*Upbar*(B^2))/((Pam*1000)*ex*(Dex^2))))^2;         %Pressure drop during exhaust valve

%New P1 from pumping losses
P1 = (Pi-DelPiv)/1000;                                                     %initial pressure kPa

%Pumping work
pmep = DelP + DelPiv + DelPev;
Wpump = (pmep/1000)*(0.01*Vd/np);                                          %Pumping work for intake
%Wpump = Win + Wex;

%Isentropic Compression Block
span = linspace(-pi,thetas);
soln = ode45(@(t,y) Project2_Elaw_close_derivs_W_HT(t,y, k, 0.001*Vd/np, R, r, m_mix, n, a,thetas,thetad, Qhv, AF, L, B, N, Rsp), span, [P1,0]);
theta_comp = soln.x;
W_comp = soln.y(2,:);
P_comp = soln.y(1,:);
V_comp = volume(theta_comp,0.001*Vd/np,r,R);

%%%%Task 1 (get t2,p2)%%%%
P2 = P_comp(end);                                                          %pressure at theta 0 ie. end of comp
W2 = W_comp(end);                                                          %work at theta 0 per mass
WWM = W2/m_mix;                                                            %work compression 
V2 = V_comp(end);
T2 = (P2*V2)/(m_mix*Rsp);

%%%%Task 2/5 (get T3 and P3)%%%%

%Comb block
span = linspace(thetas,thetas+thetad);
soln = ode45(@(t,y) Project2_Elaw_close_derivs_W_HT(t,y, k, 0.001*Vd/np, R, r, m_mix, n, a,thetas,thetad, Qhv, AF, L, B, N, Rsp), span, [P2,W2]);
theta_comb = soln.x;
W_comb = soln.y(2,:);
P_comb = soln.y(1,:);
V_comb = volume(theta_comb,0.001*Vd/np,r,R);

P3 = P_comb(end);
V3 = V_comb(end);
W3 = W_comb(end);                                                          %No work done
T3 = (P3*V3)/(m_mix*Rsp);



%%%%Task 3%%%%
%Isentropic Expansion block
span = linspace(thetas+thetad, pi);
soln = ode45(@(t,y) Project2_Elaw_close_derivs_W_HT(t,y, k, 0.001*Vd/np, R, r, m_mix, n, a,thetas,thetad, Qhv, AF, L, B, N, Rsp), span, [P3,W3]);
theta_exp = soln.x;
P_exp = soln.y(1,:);
W_exp = soln.y(2,:);
V_exp = volume(theta_exp,0.001*Vd/np,r,R);

P4 = P_exp(end);
W4 = W_exp(end);
Wexppkg = W4/m_mix;                                                        %work compression [kJ/kg]
V4 = V_exp(end);
T4 = P4*V4/(m_mix*Rsp);


%%%% Task 8 %%%%
%Friction
cps = 294;                                                                 %constant(kPa-mm-s/m)
cpr = 4.06e+4;                                                             %constant(kPa-mm^2)
cg = 6.89;
K_g = 2.38e-2;
%Piston Skirt
fmep_S = cps*(Vintake/(B*1000));
%Piston Rings
fmep_R = cpr*(1+(1000/N))*(1/(B*1000)^2); 
%Piston Gas
fmep_G  = cg*(DelP/(Pam*1000))*(0.088*r + 0.182*(r^(1.33-K_g*Vintake)));
%Total Pressure losses from fric
fmep = (fmep_S +fmep_R+fmep_G);


%%%% Task 4 %%%%
%Getting work values

W_tot = Wexppkg;                                                           %Total work [kJ]
Wi = W4 - Wpump;
Pow = 6*(Wi/2)*N/60;                                                       %Indicated power [kW] per engine
Tor = 1000*Pow/(2*pi*N/60);                                                %Indicated Torque 
IMEP = (P1/(Rsp*T1))*(r/(r-1))*W_tot;                                      %Mean effective pressure [kPa]
m_dot_f = 6*(m_mix/(AF+1))*N/(2*60);                                       %Mass flow rate of fuel per engine[kg/s]
m_dot_f_hr = m_dot_f*3600;                                                 %Fuel flow rate per hour per engine
isfc = (m_dot_f_hr)*1000/Pow; 

%%%% Task 9 %%%%
Wf = (0.001*Vd/np)*fmep;                                                   %Friction work 
Wb = Wi - Wf;                                                              %Brake work 

%Brake Params
n_eff = Wb/Wi;                                                             %Mechanical Efficiency
bmep = Wb/(0.001*Vd/np);                                                   %BMEP
Pb = (Wb/2)*(np*N/60);                                                     %Brake Power
Tb = 1000*Pb/(2*pi*(N/60));                                                %Brake Torque
bsfc = (m_dot_f_hr)*1000/Pb;                                               %bsfc

Power(1,i) = Pow;
Torque(1,i) = Tor;
RPM(1,i) = N;
PBr(1,i) = Pb;
TBr(1,i) = Tb;

Work4(1,i) = Wpump;
WorkPump(1,i) = W4;

i = i+1;


end

figure()
plot(RPM,Power);
hold on
plot(RPM,PBr);
hold off
xlabel('RPM')
ylabel('Engine Power [kW]')
legend('Engine Power','Brake Power')

figure()
plot(RPM,Torque);
hold on
plot(RPM,TBr);
hold off
xlabel('RPM')
ylabel('Torque [N-m]')
legend('Engine Torque','Brake Torque')

figure()
plot(RPM,Work4);

xlabel('RPM')
ylabel('Work Pump [kJ]')

figure()
plot(RPM,WorkPump);
xlabel('RPM')
ylabel('Work 4 [kJ]')



