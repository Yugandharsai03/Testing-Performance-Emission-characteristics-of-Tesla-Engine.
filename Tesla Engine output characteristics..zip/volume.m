%computes the  volume and its derivatives.
%inputs = theta,displacement volume ,R, r.
%outputs = volume and its derivatives.
function [V,dV] = volume (theta,Vd,R,r)

Vc = Vd/(r-1);
     V  = Vc*(1 + 0.5*(r-1).*(R+1-cos(theta) -(R.^2-(sin(theta)).^2).^0.5));
    dV = 0.5*Vc*(r-1).*sin(theta).*(1+cos(theta)./sqrt(R.^2-(sin(theta)).^2));
end

