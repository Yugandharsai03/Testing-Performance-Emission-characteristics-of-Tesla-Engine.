function S_Area = Project2_area_(theta, L, B, R)
                                                                           %getting Q_dot heat transfer
                                                                           %Q_HT = h*Area(theta)*(T(theta))-Twall (twall ~= 80cel
                                                                           %Function for a
        
                                                                           %T = PV(Theta)/mR 
                                                                           %a = 0.49; %4stroke
                                                                           %Re = p*U*Lch/u;
                                                                           %Nu = a * Re^0.7;
    S_Area = (pi/2)*B^2 + (pi*B)*(L/2).*((R+1-cos(theta)-((R.^2) - (sin(theta))^2).^0.5)); %area function
end